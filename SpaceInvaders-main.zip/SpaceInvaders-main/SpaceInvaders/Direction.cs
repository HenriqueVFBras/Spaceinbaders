﻿namespace SpaceInvaders;

public enum Direction
{
    Up,
    Right,
    Down,
    Left
}