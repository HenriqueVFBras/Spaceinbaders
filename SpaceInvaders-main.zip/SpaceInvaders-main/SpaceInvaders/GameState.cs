﻿namespace SpaceInvaders;

public enum GameState
{
    Starting,
    Menu,
    Playing,
    GameOver
}